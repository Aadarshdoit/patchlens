class StudentNotFoundError(Exception):
    pass